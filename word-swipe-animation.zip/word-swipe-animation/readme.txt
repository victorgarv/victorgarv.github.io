This template / effect / code has been created by Eric Porter.
You can customize and check it out on its original site on the following link:
https://codepen.io/EricPorter/pen/JjPmOOb

Thank you